#packages à installer :

pip install -r requirements.txt 


#Pour lancer l'API :

sudo apt install uvicorn

uvicorn main:app --reload

